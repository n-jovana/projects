<?php
    session_start(); error_reporting(0);
    include "php/konekcija.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("ukljuci/head.php");?>
</head>
<body>
        
     <div id="prozor">
        <div id="obavestenje">
            <p>Proizvod je dodat u korpu!</p>
        </div>
    </div>   	
    <div id="topbar">
        <div class="content">  			
            <?php include "php/meni.php";?>
		</div>
    </div> 

    <div id="omot">
        <div class="content" style="min-height: 700px">
            <section id="forme">
				<?php include "ukljuci/forme.php";?>
			 </section>
            <div class="flexed">  
				<form action="" class="forms">
                    <h2>Pretraga:</h2>
                    <input type="text" id="pretraga" placeholder="Pretraga..."/>
                </form>
				<form action="" class="forms">
                    <h2>Filteri:</h2>
                    <select name="Tip" id="Tip" style="width:49%">
                        <option value='0'>Izaberite...</option>
                        <?php
                        $upit = ("SELECT id, nazivKategorije FROM kategorije");
                        $rezultat = $konekcija->query($upit);
                        $proizvodi = $rezultat->fetchAll();
                        foreach($proizvodi as $proizvod):
                    ?>
                        <option value=<?= $proizvod->id?>><?= $proizvod->nazivKategorije?></option>
                    <?php
                        endforeach;
                    ?>    
                    </select>
                    <select name="Cena" id="Cena" style="width:50%">
                        
                            <option value = "0">Sortiraj...</option>
                            <option value = "1">Cena - rastuće</option>
                            <option value = "2">Cena - opadajuće</option>
                            <option value = "3">Naziv - rastuće</option>
                            <option value = "4">Naziv - opadajuće</option>
                        
                    </select>
                </form>
                
            </div>
            <section id="prikazProizvoda">
                <div class="karte" id="proizvodi">
                    <?php include "php/ispisProizvoda.php"; ?>
                </div>
            </section>
        </div>

        <div id="paginacija"> 
			<ul> 
				<?php 
				$upit1 = "SELECT COUNT(*) AS brojProizvoda FROM proizvodi"; 
				$rezultat1 = $konekcija->query($upit1)->fetch();  
 				$brojProizvoda = $rezultat1->brojProizvoda; 
  				$brojLinkova = ceil($brojProizvoda / 3);  
 				for($i=1; $i <= $brojLinkova; $i++){ 
					 $id = "$i"; 
					 
				?> 
				<li> 
					<a data-page="<?=$id?>" class = "linkPaginacija" href="#"> <?= $i ?> </a> 
				</li> 
				
				<?php 
				} 
				?> 

			</ul> 
		 </div>

        <?php include("ukljuci/footer.php");?>
    </div>

    <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="assets/js/script.js"></script>
    <script type="text/javascript" src="assets/js/navbar.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/objekat.js"></script>
    <script type="text/javascript" src="assets/js/kreiraj.js"></script>
    <script type="text/javascript" src="assets/js/prikaz.js"></script>
    <script type="text/javascript" src="assets/js/prod-modal.js"></script>    
</body>
</html>