<?php
    session_start();
    include "php/konekcija.php";
    if(isset($_SESSION['korisnik'])){
		if($_SESSION['uloga'] != 1){
			$code = 404; 
			http_response_code($status);
		}
		else if($_SESSION['uloga'] == 1){ 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("ukljuci/head.php");?>
</head>
<body>
      <div id="prozor">
        <div id="obavestenje">
            <p>Proizvod je dodat u korpu!</p>
        </div>
    </div>   	
    <div id="topbar">
        <div class="content">  			
            <?php include "php/meni.php";?>
		</div>
    </div>  
    <div id="omot">
		<h1 class="text-center">Dodavanje proizvoda</h1>
    <div id="formaZaInsert">
                <form action="php/ubaciProizvod.php" name="formularInsert" method="POST" enctype="multipart/form-data">
                        <table id="tabelaDodajProizvod">                                
                                <tr>
                                    <td>
                                        <input type="text" name="tbTipPro" id="tipPro" placeholder="Tip proizvoda"  class="form-control"/>
                                    </td>
                                </tr>
                                <tr>
                                <tr>
                                    <td>
                                        <select name="tbKategorijaPro" id="kategorijaPro" class="form-control">
                                            <option value="Izaberite">Izaberite kategoriju</option>
                                            <?php
                                            include "php/dodajKat.php";
                                            ?>
                                        </select>
                                    </td>
                                </tr>  
                                <tr>  
                                    <td>
                                        <input type="text" name="tbModelPro" id="modelPro" placeholder="Model proizvoda"  class="form-control"/>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td>
                                        <select name="tbEkranPro" id="ekranPro"  class="form-control">
                                        <option value="Izaberite">Izaberite ekran</option>
                                            <?php
                                            include "php/dodajEkran.php";
                                            ?>
                                        </select>    
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="tbRamPro" id="ramPro" placeholder="Ram memorija"  class="form-control"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="tbProcesor" id="procesorPro" placeholder="Procesor" class="form-control" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="tbGrafika" id="grafikaPro" placeholder="Grafika"  class="form-control" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="tbOcena" id="ocenaPro" placeholder="Ocena" class="form-control" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="tbCena" id="cenaPro" placeholder="Cena" class="form-control" />
                                    </td>
                                </tr>
								<tr>  
                                    <td >
                                        
										<input type="file" name="tbSlikaPro" id="slikaPro"/> 
                                    </td>
                                </tr>
                
                                <tr>
                                    <td>
                                        <input type="submit" class="btn btn-success" name="btnDodajPro" id="dodajPro" value="Dodajte proizvod"/>

                                    </td>
                                </tr>
								
                            </table>
                </form>
            </div>
			<div class="content" >
			<br/>
			<h1 class="text-center">Pregled i brisanje proizvoda</h1>
            <div id = "tabelaPro">
                <table id="tabPro" class="table table-striped">
                    <tr>
                        <th>Slika</th>
                        <th>Marka</th>
                        <th>Tip</th>
                        <th>Ocena</th>
                        <th>Cena</th>
                        <th>Promeni</td>
                    </tr>
                    <?php
                        $upitTabela = "SELECT p.id as id, s.putanja as slika, k.nazivKategorije as kategorija, p.tip as tip, p.ocena as ocena, p.cena as cena FROM proizvodi p INNER JOIN slike s ON p.slikaId = s.id INNER JOIN kategorije k ON p.kategorijaId = k.id";
                        $priprema = $konekcija->query($upitTabela);
                        $proizvodi = $priprema->fetchAll();
                      
                        foreach($proizvodi as $pro): ?>
                            <tr>   
                                <td>
                                    <img src="<?php echo $pro->slika ?>" />
                                </td> 
                                <td>
                                    <?php echo $pro->kategorija ?>
                                </td>   
                                <td>
                                    <?php echo $pro->tip ?>
                                </td>
                                <td>
                                    <?php echo $pro->ocena ?>
                                </td>  
                                <td>
                                    <?php echo $pro->cena ?>
                                </td> 
                                <td>
                                    <input type="button" class="obrisi btn btn-danger" data-id=" <?php echo $pro->id?> " value = "Obriši" />
                                </td>
                            </tr>
                    <?php endforeach; ?>
                    
                </table>
            </div>
			</div>
            

         <?php include("ukljuci/footer.php");?>
    </div>

    <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="assets/js/navbar.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/objekat.js"></script>
    <script type="text/javascript" src="assets/js/kreiraj.js"></script>
    <script type="text/javascript" src="assets/js/prikaz.js"></script>
    <script type="text/javascript" src="assets/js/prod-modal.js"></script>
    <script type="text/javascript" src="assets/js/admin.js"></script>    
</body>
</html>
<?php }}
else{
	$status = 404; 
	http_response_code($status); 
}
?>