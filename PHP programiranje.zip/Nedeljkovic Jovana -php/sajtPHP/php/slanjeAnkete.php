<?php
    session_start();
    
    
    
    http_response_code($status);
?>