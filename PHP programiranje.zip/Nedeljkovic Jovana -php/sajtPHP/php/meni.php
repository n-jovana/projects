<a href="index.php"><img src="images/logo.png" style="width:100px" class="mojlogo"></a>
<?php
include "konekcija.php";
$upit = "SELECT * FROM meni";
$priprema=$konekcija->prepare($upit);
$priprema->execute();
$linkovi=$priprema->fetchAll();

$niz=["fa fa-home", "fa fa-desktop", "fa fa-user", "fa fa-envelope"];
$ispis="<div class='menu hidden-xs' style='width:100%'>	<ul style='float:right'>";
foreach($linkovi as $link){
	for($i=0;$i<count($niz);$i++){
		if($i+1 == $link->idMeni)
			$ispis .="<li><a href='$link->putanja'><i class='$niz[$i]'></i>$link->naslov</a></li>";
	}
}

$ispis .="<li> <a  href=\"anketa.php\"><i class=\"fa fa-bar-chart\"></i> Anketa</a></li>

<li> <a href=\"korpa.php\"><i class=\"fa fa-shopping-cart\"></i> Korpa</a></li>

";

if($_SESSION['korisnik']=="")
	$ispis .= "<li> <a href=\"#\" data-toggle=\"modal\" data-target=\"#register\"><i class=\"fa fa-plus\"></i> Registracija</a></li>";
else
	$ispis .= "<li> <a href=\"php/odjava.php\"> <i class=\"fa fa-lock\"></i> Odjava</a></li>";

$ispis.="</ul></div>";
echo $ispis;


if($_SESSION['korisnik']=="")
{
?>
	<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#login"  style="float:right"><i class="fa fa-unlock"></i> Prijava</button>
<?php
}
else
{
	if($_SESSION['uloga'] == 1)
		$link = "admin.php";
	else
		$link = "proizvodi.php";
	
	?>
	<a href="<?php echo $link;?>" class="btn btn-primary btn-lg" style="float:right"><i class="fa fa-user"></i> Zdravo, <?php echo $_SESSION['korisnik'];?></a>
	
	
<?php
}
?>

<span style="font-size:30px;cursor:pointer;margin-top:-40px;color:#fff" onclick="openNav()" class="visible-xs">&#9776;</span>


<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <?php
  $ispis="";
	foreach($linkovi as $link){
		for($i=0;$i<count($niz);$i++){
			if($i+1 == $link->idMeni)
				$ispis .="<a href='$link->putanja'><i class='$niz[$i]'></i>$link->naslov</a>";
		}
	}

	$ispis .=" <a  href=\"anketa.php\"><i class=\"fa fa-bar-chart\"></i> Anketa</a>

	<a href=\"korpa.php\"><i class=\"fa fa-shopping-cart\"></i> Korpa</a>

	";

	if($_SESSION['korisnik']=="")
		$ispis .= " <a href=\"#\" data-toggle=\"modal\" data-target=\"#register\"><i class=\"fa fa-plus\"></i> Registracija</a>";
	else
		$ispis .= " <a href=\"php/odjava.php\"> <i class=\"fa fa-lock\"></i> Odjava</a>";
	echo $ispis;
	
	if($_SESSION['korisnik']=="")
	{
	?>
		<a type="button"  data-toggle="modal" data-target="#login"><i class="fa fa-unlock"></i> Prijava</a>
	<?php
	}
	else
	{
		if($_SESSION['uloga'] == 1)
			$link = "admin.php";
		else
			$link = "proizvodi.php";
		
		?>
		<a href="<?php echo $link;?>"  ><i class="fa fa-user"></i> Zdravo, <?php echo $_SESSION['korisnik'];?></a>
	<?php
	}
	
	
	?>
  
</div>

<div id="main">
	
</div>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";
}
</script>
