<?php
  session_start();error_reporting(0);
?>  

<!DOCTYPE html>
<html lang="en">
<head>
     <?php include("ukljuci/head.php");?>
</head>
<body>
    <div id="prozor">
        <div id="obavestenje">
            <p>Proizvod je dodat u korpu!</p>
        </div>
    </div>   	
    <div id="topbar">
        <div class="content">  			
            <?php include "php/meni.php";?>
		</div>
    </div>  
    <div id="omot">
        <div class="content" style="min-height: 700px">
            <div class="flexed">
              <form action="" class="form">
                <h2>Pošaljite sugestiju ili pitanje administratoru sajta</h2>
                <p id="SubmitMessage"></p>
                <div class="form-wrap">
                    <label for="loginField">Email</label>
                    <input type="email" id="loginField" placeholder="Vaša email adresa" class="input-field"/>
                    <small id="emailMessage"></small>
                </div>
                <div class="form-wrap">
                    <label for="naslov">Naslov</label>
                    <input type="text" id="naslov" placeholder="Unesite naslov poruke" class="input-field"/>
                    <small id="naslovMessage"></small>
                </div>
                <div class="form-wrap">
                    <label for="opis">Vaša poruka</label>
                    <textarea name="opis" id="opis" cols="30" rows="10" class="input-field"></textarea>
                 </div>
                <div class="form-wrap">
                    <button type="button" id="loginButton" class="button primary">Pošaljite poruku</button>
                </div>
              </form>
              <canvas id="myChart" width="200" height="200"></canvas>
            </div>
        </div>

        
    </div>

    <script type="text/javascript" src="assets/js/jquery.js"></script>
    <script type="text/javascript" src="assets/js/navbar.js"></script>
    <script type="text/javascript" src="assets/js/regular.js"></script>
    <script type="text/javascript" src="assets/js/loadRegular2.js"></script>
    <script type="text/javascript" src="assets/js/Chart.min.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>

</body>
</html>