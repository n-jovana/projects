<?php session_start(); error_reporting(0);?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("ukljuci/head.php");?>
</head>
<body>
   	
    <div id="topbar">
        <div class="content">  			
            <?php include "php/meni.php";?>
		</div>
    </div>  
    <div id="omot">
        <div class="content" style="min-height: 600px">
            <section id="forme">
				<?php include "ukljuci/forme.php";?>
			 </section>
			<div class="flexed">
              <div id="levo">
                <img class="bordered" src="images/autor.jpg" alt="Autor" style="width:90%"/>
              </div>
              <div id="desno">
                <h3>Jovana Nedeljković 68/17</h3>
                
                <!-- Ovde ispisati tekst -->
                <p>Zdravo, zovem se Jovana Nedeljković</p>
                <p>Student sam Visoke ICT skole, smer Informacione tehnologije. Broj indeksa 68/17</p>
               </p>
                <p></p>
              </div>
            </div>
        </div>
        <?php include("ukljuci/footer.php");?>
    </div>
    <script type="text/javascript" src="assets/js/main.js"></script>
</body>
</html>