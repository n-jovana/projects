<footer id="footer">           
	<ul>
		<li><a href="index.php"><i class="fa fa-home"></i> Početna</a></li>
		<li><a href="proizvodi.php"><i class="fa fa-desktop"></i> Proizvodi</a></li>
		<li><a href="kontakt.php"><i class="fa fa-phone"></i> Kontakt</a></li>
		<li><a href="autor.php"><i class="fa fa-user"></i> Autor</a></li>
		<li><a href="sitemap.xml"><i class="fa fa-map"></i> Sitemap</a></li>
		<li><a href="dokumentacija.pdf"><i class="fa fa-docs"></i> Dokumentacija</a></li>
	</ul>
	<p>
		Jovana Nedeljkovic 68/17
	</p>
</footer>