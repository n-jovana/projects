<?php
if(isset($_POST['register'])){
	$greske = [];

	$ime = $_POST['ime'];
	
	$reIme = "/^[A-Z][a-z]{2,20}(\s[A-Z][a-z]{2,20})*$/";
	if($ime == ""){
		$greske[] = "Polje za ime mora biti popunjeno";
	}

	$prezime = $_POST['prezime'];
	$rePrezime = "/^[A-Z][a-z]{2,20}(\s[A-Z][a-z]{2,20})*$/";
	if( $prezime == ""){
		$greske[] = "Polje za prezime mora biti popunjeno";
	}

	$lozinka = $_POST['lozinka'];
	$reLozinka = "/^([a-zA-Z0-9@*#]{8,15})$/";
	if($lozinka == ""){
		$greske[] = "Polje za lozinku mora biti popunjeno";
	}

	$email = $_POST['email'];
	$reEmail = "/^\w+([\._-]?\w+)*@\w+([\._-]?\w+)*(\.\w{2,4})+$/";
	if($email==""){
		$greske[] = "Polje za email mora biti popunjeno";
	}

	if(count($greske)>0){
		?>
		<div class="alert alert-danger">
		<?php
		foreach($greske as $greska)
			echo $greska."<br/>";
		?>
		</div>
		<?php
	}
	else{
		$upit = "INSERT INTO korisnik (ime, prezime, email, lozinka, ulogaId) VALUES(:ime, :prezime, :email, :lozinka, 2)";
		
		$priprema = $konekcija->prepare($upit); 
		$priprema->bindParam(':ime', $ime); 
		$priprema->bindParam(':prezime', $prezime); 
		$priprema->bindParam(':email', $email); 
		$priprema->bindParam(':lozinka', $lozinka); 
		
		try{ 
			$status = $priprema->execute(); 
			?>
			<div class="alert alert-success">
				Uspešno ste se registrovali
			</div>
			<?php
		} 
		catch(PDOException $e){ 
			$status = 409; 
			?>
			<div class="alert alert-danger">
				Nešto je pošlo naopako.
			</div>
			<?php
		}
	}
	
}

if(isset($_POST['login'])){
	 $greske = [];
		
        $email = $_POST['email'];
        $reEmail = "/^([a-z0-9\.]+)([@]{1}[a-z]{3,}[\.]{1}(edu[\.])?(com|rs|org|net))$/";
        if($email == ""){
            $greske[] = "Polje za email mora biti popunjeno";
        }


        $lozinka = $_POST['lozinka'];
        $reLozinka = "/^(?=.*\d)(?=.*[a-zšžđćč])(?=.*[A-ZŠŽĐĆČ])[0-9a-zšžđćčA-ZŠŽĐĆČ]{8,}$/";
        if($lozinka == ""){
            $greske[] = "Polje za lozinku mora biti popunjeno";
        }
        if(count($greske)>0) {
           
			$status = 422;
            $pod = $greske;
			
			?>
			<div class="alert alert-danger">
				Niste sve popunili
			</div>
			<?php
        }
        else {
			
            $upit = "SELECT * FROM korisnik WHERE email=:email AND lozinka=:lozinka";
            $priprema = $konekcija->prepare($upit);  
            $priprema->bindParam(':email', $email); 
            $priprema->bindParam(':lozinka', $lozinka); 
            $rezultat = $priprema->execute();

            if($rezultat){
				
                if($priprema->rowCount()>0){
                    $status = 201;
                    
                    
					
					$rows = $priprema->fetchAll(PDO::FETCH_ASSOC);
															
					foreach($rows as $row)
					{
						$_SESSION['korisnik'] = $row['ime'];
						$_SESSION['korisnikID'] = $row['id'];
						$_SESSION['uloga'] = $row['ulogaId'];
						
					}
                    if($_SESSION['uloga']==1){
                        $pod = 'admin';
						header("location:admin.php");
                    }
                    else{
                        $status = 200;
                        $pod = 'korisnik';
                        header("location:proizvodi.php");

                    }
                }
                else{
                    if($priprema->rowCount()==0){
                        ?>
						<div class="alert alert-danger">
							Niste registrovani
						</div>
						<?php
                    }
                }
            }
            else{
                $status=402;
            }
        }
	
}
?>


			<!-- Trigger the modal with a button -->


<!-- Modal -->
<div id="register" class="modal fade" role="dialog" style="z-index:111111">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Otvaranje naloga</h4>
      </div>
      <div class="modal-body">
        <form action="" name="formular" method="post">
					Ime:
					<input type="text" class="form-control" name="ime" id="ime2" placeholder="Ime"/><br/>
					Prezime:
					<input type="text" class="form-control" name="prezime" id="prezime2" placeholder="Prezime"/><br/>
					Email:
					<input type="email" class="form-control" name="email" id="email2" placeholder="Email"/><br/>
					Lozinka:
					<input class="form-control" type="password" name="lozinka" id="lozinka2" placeholder="Lozinka" /><br/><br/>
			 
					<input type="submit" name="register"  class="btn btn-success" name="btnKreiraj" value="Kreirajte nalog"/><br/>
				  
			  
			<h3 id="uspesno"></h3>
                    
        </form>
      </div>
      
    </div>

  </div>
</div>

<div id="login" class="modal fade" role="dialog" style="z-index:111111">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Prijava na sistem</h4>
      </div>
      <div class="modal-body">
        <form action="" name="formular" method="post">
					Email:
					<input type="email" class="form-control" name="email" id="email2" placeholder="Email"/><br/>
					Lozinka:
					<input class="form-control" type="password" name="lozinka" id="lozinka2" placeholder="Lozinka" /><br/><br/>
			 
					<input type="submit" name="login"  class="btn btn-success" name="btnKreiraj" value="Prijava"/><br/>
				  
			  
			<h3 id="uspesno"></h3>
                    
        </form>
      </div>
      
    </div>

  </div>
</div>