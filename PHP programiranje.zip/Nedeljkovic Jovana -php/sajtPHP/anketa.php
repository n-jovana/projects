<?php    session_start(); error_reporting(0);
include "php/konekcija.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("ukljuci/head.php");?>
</head>
<body>
    <div id="topbar">
        <div class="content">  			
            <?php include "php/meni.php";?>
		</div>
    </div>  
	<section id="forme">
				<?php include "ukljuci/forme.php";?>
			 </section>
	<?php
	if(isset($_POST['send']))
	{
		
		if(isset($_POST['marka'])){
			$marka = $_POST['marka'];
		}
		if(isset($_POST['sajt'])){
			$sajt = $_POST['sajt'];
		}

		$upit1 = "INSERT INTO anketa(marka,sajt) VALUES('$marka', '$sajt')";
		$priprema=$konekcija->prepare($upit1);
		
		$status = $priprema->execute();
		$idAnketa = $konekcija->lastInsertId();
	
		$idKorisnik = $_SESSION['korisnikID'];
		$upit2 = "INSERT INTO korisnikanketa(idKorisnik, idAnketa) VALUES($idKorisnik, $idAnketa)";
		
		$priprema=$konekcija->prepare($upit2);		
		$status = $priprema-> execute() ;
		
	}
	?>
    <div id="omot">
        <?php 
		$upit= "SELECT * FROM anketa";
		$priprema=$konekcija->prepare($upit);
		$priprema->execute();
		$brUkupno=$priprema->rowCount();
		?>
		<?php
		if(isset($_SESSION['korisnik'])){
			$id=$_SESSION['korisnikID'];
			$upit='SELECT  * FROM korisnikanketa WHERE idKorisnik=:id';
			$priprema=$konekcija->prepare($upit);
			$priprema->bindParam(":id", $id);
			$rezultat=$priprema->execute();
			$redovi=$priprema->rowCount();
               
            
        ?><br/>
		<h1 class="text-center">Popunite anketu</h1>
        <form method="post" action="" >
            <table id="tabelaAnketa">
                
            <tr>
                <td colspan="10"><br/>Omiljena marka računara?<br><br>
            
            
                
                    <input type="radio" name="marka" class="rbMarka" value="Apple"> Apple 
					<?php										
					$upit = "SELECT * FROM anketa WHERE marka='Apple'"; 
					$priprema=$konekcija->prepare($upit);    
					$priprema->execute();  
					$redBr = $priprema->rowCount(); 
					$procenat = round($redBr/$brUkupno*100);					
					echo "(".$procenat."%)" 
					?><br>
                    <input type="radio" name="marka" class="rbMarka"  value="HP"> HP
					<?php										
					$upit = "SELECT * FROM anketa WHERE marka='HP'"; 
					$priprema=$konekcija->prepare($upit);    
					$priprema->execute();  
					$redBr = $priprema->rowCount(); 
					$procenat = round($redBr/$brUkupno*100);					
					echo "(".$procenat."%)" 
					?><br>
					
                    <input type="radio" name="marka" class="rbMarka" value="Dell"> Dell
					<?php										
					$upit = "SELECT * FROM anketa WHERE marka='Dell'"; 
					$priprema=$konekcija->prepare($upit);    
					$priprema->execute();  
					$redBr = $priprema->rowCount(); 
					$procenat = round($redBr/$brUkupno*100);					
					echo "(".$procenat."%)" 
					?><br>
                    <input type="radio" name="marka" class="rbMarka" value="Lenovo"> Lenovo
					<?php										
					$upit = "SELECT * FROM anketa WHERE marka='Lenovo'"; 
					$priprema=$konekcija->prepare($upit);    
					$priprema->execute();  
					$redBr = $priprema->rowCount(); 
					$procenat = round($redBr/$brUkupno*100);					
					echo "(".$procenat."%)" 
					?><br>
                    <input type="radio" name="marka" class="rbMarka" value="Acer"> Acer
					<?php										
					$upit = "SELECT * FROM anketa WHERE marka='Acer'"; 
					$priprema=$konekcija->prepare($upit);    
					$priprema->execute();  
					$redBr = $priprema->rowCount(); 
					$procenat = round($redBr/$brUkupno*100);					
					echo "(".$procenat."%)" 
					?><br>
                </td>
            </tr>
            <tr>
                <td><br/><br/><br/>Da li ste na našem sajtu nasli sve potrebne informacije vezane za traženi proizvod?<br><br>
                    <input type="radio" name="sajt" class="sajt" value="Da"> Da
					<?php										
					$upit = "SELECT * FROM anketa WHERE sajt='Da'"; 
					$priprema=$konekcija->prepare($upit);    
					$priprema->execute();  
					$redBr = $priprema->rowCount(); 
					$procenat = round($redBr/$brUkupno*100);					
					echo "(".$procenat."%)" 
					?>
					<br>
                    <input type="radio" name="sajt" class="sajt" value="Ne"> Ne
					<?php										
					$upit = "SELECT * FROM anketa WHERE sajt='Ne'"; 
					$priprema=$konekcija->prepare($upit);    
					$priprema->execute();  
					$redBr = $priprema->rowCount(); 
					$procenat = round($redBr/$brUkupno*100);					
					echo "(".$procenat."%)" 
					?>
                </td>
            </tr>
            <tr id="poslednji"><br/><br/>
                <td><input type="submit" name="send" value="Pošalji" class="btn btn-primary"/></td>
                <p id="upozorenje"></p>
            </tr>
            </table>
        </form>
                <br/><br/><br/><br/>
         
                
        <?php } 
        else{ ?>
            <h1 id="morateSeLogovati">Morate se prvo ulogovati!</h1>
        <?php } ?>

         <?php include("ukljuci/footer.php");?>
    </div>

    <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
    <!--<script type="text/javascript" src="assets/js/script.js"></script>-->
    <script type="text/javascript" src="assets/js/navbar.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/objekat.js"></script>
    <script type="text/javascript" src="assets/js/kreiraj.js"></script>
    <script type="text/javascript" src="assets/js/prikaz.js"></script>
    <script type="text/javascript" src="assets/js/prod-modal.js"></script>   
    <script type="text/javascript" src="assets/js/anketa.js"></script>  
</body>
</html>