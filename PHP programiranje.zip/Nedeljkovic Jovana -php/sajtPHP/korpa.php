<?php
session_start();error_reporting(0);
?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("ukljuci/head.php");?>
</head>
<body>   
    <div id="topbar">
        <div class="content">  			
            <?php include "php/meni.php";?>
		</div>
    </div>  
	<section id="forme">
		<?php include "ukljuci/forme.php";?>
	 </section>
    <div id="omot">
		<?php include("ukljuci/footer.php");?>
    </div>

    <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="assets/js/navbar.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>
	<script type="text/javascript" src="assets/js/korpa.js"></script>    
</body>
</html>