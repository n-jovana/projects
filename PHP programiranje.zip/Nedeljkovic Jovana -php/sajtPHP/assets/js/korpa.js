

$(document).ready(function(){
    let proizvodi = proizvodiUKorpi();

    if(!proizvodi.length)
    prikaziPraznuKorpu();
    
    else
    prikaziSadrzajKorpe();


});


function prikaziSadrzajKorpe(){
    let proizvodi = proizvodiUKorpi();
        $.ajax({
            url:"php/korpa.php",
            method:"POST",
            data:{
                pro : proizvodi,
                send: true
            },
            success:function(data){
                $("#omot").html(data);
                /*KonacnoCena(data);*/
            }        
        });
    }


function prikaziPraznuKorpu(){
    $("#omot").html("<h1 class='prazna'>Korpa je prazna!</h1>");
}

function proizvodiUKorpi(){
    return JSON.parse(localStorage.getItem("proizvodi"));
}

function UkloniIzKorpe(id) {
    let proizvodi = proizvodiUKorpi();
    let filtrirano = proizvodi.filter(pro => pro.id != id);

    localStorage.setItem("proizvodi", JSON.stringify(filtrirano));

    prikaziSadrzajKorpe();
}



