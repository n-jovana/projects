<?php session_start();error_reporting(0);
    include "php/konekcija.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("ukljuci/head.php");?>
</head>
<body>    
    <div id="prozor">
        <div id="obavestenje">
            <p>Proizvod je dodat u korpu!</p>
        </div>
    </div>   	
    <div id="topbar">
        <div class="content">  			
            <?php include "php/meni.php";?>
		</div>
    </div>   
    <div id="omot">
        <div class="content">
			 <section id="forme">
				<?php include "ukljuci/forme.php";?>
			 </section>
			 <section id="dobrodosli">
				<br/><img src="images/dobrodosli2.jpg" style="width:100%">
				<h1>Dobro došli u Tehno house - centar najboljih laptopova!</h1>
			 </section>
            <section id="najpopularniji">
                <h2>Najpopularniji proizvodi:</h2>
                <div class="karte" id="najpopularnijiPro">
                    <?php
                        $upit = ("SELECT p.id as proId, p.tip as tip, k.nazivKategorije as proizvođač, p.model as model, p.ramMemorija as ram, p.procesor as procesor, p.grafika as grafika, p.ocena as ocena, p.cena as cena, s.putanja as putanja, s.alt as alt, k.nazivKategorije as nazivKat, e.dijagonala as dijagonala, e. rezolucija as rez FROM proizvodi p INNER JOIN slike s ON p.slikaId = s.id INNER JOIN kategorije k ON p.kategorijaId = k.id INNER JOIN ekrani e ON p.ekranId = e.id ORDER BY ocena desc LIMIT 8");

                        $rezultat = $konekcija->query($upit);
                        $proizvodi = $rezultat->fetchAll();
                        foreach($proizvodi as $proizvod):
                    ?>

						<div class="karta">
							<input type="hidden" class="hidden-input" value="<?= $proizvod->proId?>"/>
								<div class="karta-image">
									<img src="<?= $proizvod->putanja?>" alt="<?= $proizvod->alt?>"/>
								</div>
								<div class="karta-text">
									<h4 class="karta-title"><?= $proizvod->proizvođač?> <?= $proizvod->model?></h4>
										<small>
											<span>Tip:</span> <?= $proizvod->tip?>
										</small>
										<small>
											<span>Proizvođač:</span> <?= $proizvod->proizvođač?>
										</small>
										<small>
											<span>Model:</span> <?= $proizvod->model?>
										</small>										  
										<small>
											<span>Procesor:<?= $proizvod->procesor?></span>
										</small>
										<small>
											<span> Dijagonala:<?= $proizvod->dijagonala?>"</span>
										</small>
										<small>
											<span>Rezolucija:<?= $proizvod->rez?></span>
										</small>													
										<small>
											<span>RAM memorija:<?= $proizvod->ram?>GB</span>
										</small>													
										<small>
											<span>Grafika:<?= $proizvod->grafika?></span>
										</small>
												
										<small class="ocena">
										<span>Ocena:</span>
										<span> <?= $proizvod->ocena?> </span>
											</small>
										<input type="button" class="Dodaj" id="btnDodaj" data-id="<?= $proizvod->proId?>" value="Dodaj u korpu"/>
										<p class="cena">
									<span><?= $proizvod->cena?>din</span> 
								</p>
							</div>
						</div>

                    <?php
                        endforeach;
                    ?>
                </div>
            </section>           
        </div>
        <?php include("ukljuci/footer.php");?>
    </div>

    <script type="text/javascript" src="assets/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="assets/js/navbar.js"></script>
    <script type="text/javascript" src="assets/js/regular.js"></script>
    <script type="text/javascript" src="assets/js/loadRegulars.js"></script>
    <script type="text/javascript" src="assets/js/objekat.js"></script>
    <script type="text/javascript" src="assets/js/carousele.js"></script>
    <script type="text/javascript" src="assets/js/prod-modal.js"></script>
    <script type="text/javascript" src="assets/js/pocetna.js"></script>
    <script type="text/javascript" src="assets/js/main.js"></script>    
</body>
</html>