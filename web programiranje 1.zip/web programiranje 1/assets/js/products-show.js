$(document).ready(function(){
     var cart = displayCart();
     $('#cart-items').html(cart['items']);
     $('#priceSum').html(cart['sum']);

     showCartNumber();

     showProducts($('.product-display'));
     $('#price-select').on('change', function(){
          var value = parseInt($('#price-select option:selected').val());
          var sort = 0;
          var sortField = document.querySelector('#sort-order');
          sort = parseInt(sortField.options[sortField.selectedIndex].value);

          sortProducts(value, sort);
     });
     
     $('#sort-order').on('change', function(){
          var sort = parseInt($('#sort-order option:selected').val());
          var value = -1;
          var valueField = document.querySelector('#price-select');
          value = parseInt(valueField.options[valueField.selectedIndex].value);

          sortProducts(value, sort);
     });

     $('#search').on('keyup', function(){
          var value = $(this).val();
          productSearch(value);
     });

     if($('#featured') != null) {
          getFeatured(2, 5, $('#featured .product-display'));
     }

     if($('#recomended') != null) {
          getFeatured(0, 3, $('#recomended .product-display'));
     }

     if($('.product-card .button') != null) {
          $('.product-card .button').on('click', function() {
               createCart($(this).data('target'));
          });
     }
});

$('#button-clear').on('click', function() {
     clearCart();
     let cart = displayCart();
     $('#cart-items').html(cart['items']);
     $('#priceSum').html(cart['sum']);
     showCartNumber();
});

function showCartNumber() {
     const cartNum = document.querySelector('.cart-item-count');

     if (localStorage.getItem('cart')) {
          var object = JSON.parse(localStorage.getItem('cart'));
          console.log(cartNum);
          cartNum.innerHTML = object.length;
     }
}

function createCart(id){
     let cartItems = [];
     let doExist = false;

     if (localStorage.getItem('cart')) {
          cartItems = JSON.parse(localStorage.getItem('cart'));
          for (let i = 0; i < cartItems.length; i++) {
               if (cartItems[i].id === id) {
                    doExist = true;
               }
          }
     }

     if (doExist) {
          for (let i = 0; i < cartItems.length; i++) {
               if (cartItems[i].id === id) {
                    cartItems[i].quantity++;
               }
          }
          
     } else {
          for (let i = 0; i < products.length; i++) {
               if (products[i].id === id) {
                    products[i].quantity = 1;
                    cartItems.push(products[i]);
               }
          }
     }

     const obj = JSON.stringify(cartItems);

     localStorage.setItem('cart', obj);

     var cart = displayCart();
     $('#cart-items').html(cart['items']);
     $('#priceSum').html(cart['sum']);
     showCartNumber();
}

function clearCart() {
     localStorage.setItem('cart', '');
}

function displayCart(){
     var items = '';
     var sum = 0;
     if(localStorage.getItem('cart')){
          var storage = JSON.parse(localStorage.getItem('cart'));
          for(let i = 0; i < storage.length; i++){
               sum += storage[i].product_price * storage[i].quantity;
               items += `<tr>
                    <td>${storage[i].product_mark} ${storage[i].product_name}</td>
                    <td>${storage[i].quantity}</td>
                    <td>${storage[i].product_price} RSD</td>
               </tr>`
          }
     }else{
          items = 'Your cart is empty';
     } 

     var object = {
          'items' : items,
          'sum' : sum
     };
     return object;
}

function getFeatured(numFrom, numTo, element) {
     var temp = [];
     for(let i = numFrom; i < numTo; i++) {
          temp.push(products[i]);
     }

     var output = getProducts(temp);
     element.html(output);
}

function getProducts(display){
     var products = display;
     var output = '';

     for  (let i = 0; i < products.length; i++) {
          output += `<div class="product-card">
                    <div class="image">
                         <img src="${products[i].product_image}" alt="${products[i].product_mark}">
                    </div>
                    <div class="product-desc">
                         <div class="product-desc-about">
                              <h3>${products[i].product_mark} ${products[i].product_name }</h3>
                              <p>${products[i].product_description}</p>
                         </div>
                         <div class="product-desc-price">
                              <p>Cena: <span>${products[i].product_price}</span>RSD</p>
                              <button class="button" data-target="${products[i].id}">Dodaj u korpu</button>
                         </div>
                    </div>
               </div>`;
     }

     if(output == '') {
          output = '<p class="margin-5">Trenutno nemamo ni jedan proizvod po tom kriterijumu</p>';
     }

     return output;
}

function showProducts( wrapper, id = 0) {
     var output = getProducts(products);
     wrapper.html(output);
}

function sortProducts(price = -1, sort = 0){
     var output = '';
     if(price > -1) {
          var productTemp = [];
          if(sort == 1){
               products.sort(function(a, b) {
                    if(a.product_mark > b.product_mark){
                         return 1;
                    }else if(a.product_mark < b.product_mark){
                         return -1;
                    }else{
                         return 0;
                    }
               });

               for(let i = 0; i < products.length; i++) {
                    if(products[i].product_price <= price) {
                         productTemp.push(products[i]);
                    }
               }

               output = getProducts(productTemp);
          }
          else if(sort == 2){
               products.sort(function(a, b) {
                    if(a.product_mark < b.product_mark){
                         return 1;
                    }else if(a.product_mark > b.product_mark){
                         return -1;
                    }else{
                         return 0;
                    }
               });

               for(let i = 0; i < products.length; i++) {
                    if(products[i].product_price <= price) {
                         productTemp.push(products[i]);
                    }
               }

               output = getProducts(productTemp);
          }
          else{
               for(let i = 0; i < products.length; i++) {
                    if(products[i].product_price <= price) {
                         productTemp.push(products[i]);
                    }
               }

               output = getProducts(productTemp);
          }
     }

     if(sort == 1){
          var productTemp = [];

          if(price > -1){
               products.sort(function(a, b) {
                    if(a.product_mark > b.product_mark){
                         return 1;
                    }else if(a.product_mark < b.product_mark){
                         return -1;
                    }else{
                         return 0;
                    }
               });

               for(let i = 0; i < products.length; i++) {
                    if(products[i].product_price <= price) {
                         productTemp.push(products[i]);
                    }
               }

               output = getProducts(productTemp);
          }else{
               products.sort(function(a, b) {
                    if(a.product_mark > b.product_mark){
                         return 1;
                    }else if(a.product_mark < b.product_mark){
                         return -1;
                    }else{
                         return 0;
                    }
               });

               output = getProducts(products);
          }
     }
     
     if(sort == 2){
          var productTemp = [];
          if(price > -1) {
               products.sort(function(a, b) {
                    if(a.product_mark < b.product_mark){
                         return 1;
                    }else if(a.product_mark > b.product_mark){
                         return -1;
                    }else{
                         return 0;
                    }
               });

               for(let i = 0; i < products.length; i++) {
                    if(products[i].product_price <= price) {
                         productTemp.push(products[i]);
                    }
               }

               output = getProducts(productTemp);
          } else {
               products.sort(function(a, b) {
                    if(a.product_mark < b.product_mark){
                         return 1;
                    }else if(a.product_mark > b.product_mark){
                         return -1;
                    }else{
                         return 0;
                    }
               });

               output = getProducts(products);
          }
     } 

     setTimeout(function(){
          $('.product-display').html(output);
     }, 200);

     $('.product-card').each(function() {
          $(this).fadeOut('fast');
     });

}

function productSearch(query) {
     var products = $('.product-card');

     products.each(function() {
          var child = $(this).children()[1].children[0].children[0].innerText.toLowerCase();
          if(child.indexOf(query.toLowerCase()) > -1){
               $(this).show();
          }else{
               $(this).hide();
          }
     });
}