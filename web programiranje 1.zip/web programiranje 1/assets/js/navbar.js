const toTopBtn = $('.toTopBtn');

toTopBtn.animate({width: '64px', height: '64px'});

toTopBtn.on('click', function() {
    // $(window).scrollTop(0);
    $('html, body').animate({scrollTop: '0'});
});

const prevScrollPos = window.pageYOffset;
$(window).on('scroll', function() {
    const currentScrollPos = window.pageYOffset;
    if (currentScrollPos > prevScrollPos) {
        $('.nav').css('top', -50);
        toTopBtn.show();
    } else {
        $('.nav').css('top', 0);
        toTopBtn.hide();
    }
});