window.onload = function(){
   let location = window.location;
   
   location = String(location).split('/');
   location = location[location.length - 1];

   hamburgerMenu();
   fillSelects(location);

   const toggleLogin = document.querySelector('#toggle-login');
   const toggleRegister = document.querySelector('#toggle-register');

   toggleRegister.addEventListener('click', toggleModalState);
   toggleLogin.addEventListener('click', toggleModalState);

   const modalToggles = document.querySelectorAll(".modal-toggle");
   const closeModal = document.querySelectorAll(".close-modal");

   modalToggles.forEach(e => {
      e.addEventListener('click', ()=>{
         let modal = document.querySelector(e.getAttribute('data-modal'));
         modal.style.display = 'block';
      });
   });

   closeModal.forEach(e => {
      e.addEventListener('click', () => {
         let modals = document.querySelectorAll('.modal');
         modals.forEach(x => {
            x.style.display = 'none';
         });
      })
   });

   window.addEventListener('click', e => {
      let modals = document.querySelectorAll('.modal');
      modals.forEach(x => {
         if(e.target == x){
            x.style.display = 'none';
         }
      });
   });

   let empty = checkForInputs();
   checkRegulars(location, empty);
}

function hamburgerMenu(){
   const hamburger = document.querySelector(".toggle-button");
   const navbarCloseBtn = document.querySelector(".navbar-close-btn");

   hamburger.addEventListener('click', showMenu);
   navbarCloseBtn.addEventListener('click', closeMenu);
}

function closeMenu() {
   const navbar = $('.navbar-show');

   navbar.fadeOut('fast');
}

function showMenu(){
   const navbar = $(".navbar-show");

   navbar.fadeIn('fast');
   navbar.css("display", "flex");
}

function fillSelects(location){
   if(location == "products.html"){
      const priceSelect = document.querySelector('#price-select');

      const priceArray = [500, 1000, 2000, 5000, 9000, 10000, 20000, 30000, 60000, 80000, 100000, 150000, 200000, 300000];

      let output = `<option value="-1">Izaberite cenu...</option>`;
      for(let i = 0; i < priceArray.length; i++){
         output += `<option value="${priceArray[i]}">Manja od: ${priceArray[i]}</option>`;
      }

      priceSelect.innerHTML = output;
   }
}

function toggleModalState(){
   const login = document.querySelector('#login-section');
   const register = document.querySelector('#register-section');

   let state = this.getAttribute('data-toggle');

   if(state == '0'){
      login.style.display = 'block';
      register.style.display = 'none';
      const registerButton = document.querySelector('#toggle-register');
      registerButton.classList.remove('active');
      this.classList.add('active');
   }else{
      login.style.display = 'none';
      register.style.display = 'block';
      const loginButton = document.querySelector('#toggle-login');
      loginButton.classList.remove('active');
      this.classList.add('active');
   }
}

function checkForInputs(){
   const inputs = document.querySelectorAll('.input');
   inputs.forEach(e => {
      e.addEventListener('blur', function(){
         if(this.value == ""){
            this.style.borderColor = 'rgb(167, 33, 33)';
            return true;
         }else{
            this.style.borderColor = '#eee';
            return false;
         }
      });
   });

}