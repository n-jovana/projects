const nameReg = /^[A-Z]{1}[a-z]{2,15}[\s]{1}[A-Z]{1}[a-z]{2,15}$/;
const usernameReg = /^[\w]{4,}$/;
const emailReg = /^[\w]{3,}[@]{1}[a-z]{3,}[\.][a-z]{2,}$/;

//Minimun 8 karaktera, barem jedno slovo, 1 broj i 1 specijalan karakter
const passReg = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
const subjectReg = /^[\w]{3,}$/;
const textReg = /^[\w\.\\\!\'\?\"]{3,}$/;

function checkRegulars(location, empty){
   if(empty){
      console.log("Fields are empty");
   }else{
      const registerButton = document.querySelector('#register-button');
      const loginButton = document.querySelector('#login-button');
      if(location == 'contact.html'){
         const submitButton = document.querySelector('#contact-submit');
         submitButton.addEventListener('click', checkForContact);
      }

      registerButton.addEventListener('click', checkRegister);
      loginButton.addEventListener('click', checkLogin);
   }
}

function checkRegister(){
   const name = document.querySelector('#name-register');
   const username = document.querySelector('#username-register');
   const password = document.querySelector('#register-password');
   const repPassword = document.querySelector('#register-rep-password');
   const email = document.querySelector('#register-email');

   let errArray = [];
   if(!nameReg.test(name.value)){
      errArray.push("Name is not in valid format! Try first letter capital, then lowercase letters, space, then the same for lastname.");
   }

   if(!usernameReg.test(username.value)){
      errArray.push("Username is not i valid format! Try letters, numbers and '_'.");
   }

   if(!passReg.test(password.value)){
      errArray.push('Password must have at least 8 charchaters, at least 1 letter, at least 1 number, at least 1 special character!');
   }

   if(password.value != repPassword.value){
      errArray.push('Passwords do not match!');
   }

   if(!emailReg.test(email.value)){
      errArray.push('Email is not valid!');
   }

   let output = '';
   if(errArray.length > 0){
      errArray.forEach(e => {
         output += `<p class="message red">${e}</p>`;
      });
   }else{
      output = `<p class="message green">Success!</p>`;
   }

   document.querySelector('#register-messages').innerHTML = output;
}

function checkLogin(){
   const username = document.querySelector('#username-login');
   const password = document.querySelector('#username-password');

   let errorArr = [];

   if(!usernameReg.test(username.value)){
      errorArr.push('Username is not valid!');
   }

   if(!passReg.test(password.value)){
      errorArr.push('Password is not valid!');
   }

   let output = '';
   if(errorArr.length > 0){
      errorArr.forEach(e => {
         output += `<p class="message red">${e}</p>`;
      });
   }else{
      output = `<p class="message green">Success!</p>`;
   }

   document.querySelector('#message-login').innerHTML = output;
}

function checkForContact(){
   const name = document.querySelector('#contact-name');
   const email = document.querySelector('#contact-email');
   const subject = document.querySelector('#contact-subject');
   const text = document.querySelector('#contact-text');

   let errArray = [];
   if(!nameReg.test(name.value)){
      errArray.push("Name is not in valid format! Try first letter capital, then lowercase letters, space, then the same for lastname.");
   }

   if(!emailReg.test(email.value)){
      errArray.push('Email is not valid!');
   }

   if(!subjectReg.test(subject.value)){
      errArray.push('Subject must have only letters and numbers!');
   }

   if(!textReg.test(text.value)){
      errArray.push('Your text contains forbiden charachters!');
   }

   let output = '';
   if(errArray.length > 0){
      errArray.forEach(e => {
         output += `<p class="message red">${e}</p>`;
      });
   }else{
      output = `<p class="message green">Success!</p>`;
   }

   document.querySelector('#messages-contact').innerHTML = output;
}
